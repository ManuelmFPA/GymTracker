package com.gymtracker.repository;

import com.gymtracker.entity.Exercise;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ExerciseRepository extends JpaRepository<Exercise, Long> {

    @Query("""
            SELECT e FROM Exercise e
            WHERE e.active = true
            AND (:muscleGroup IS NULL OR e.muscleGroup = :muscleGroup)
            AND (:equipment IS NULL OR e.equipment = :equipment)
            AND (:search IS NULL OR LOWER(e.name) LIKE LOWER(CONCAT('%', :search, '%')))
            ORDER BY e.muscleGroup, e.name
            """)
    List<Exercise> search(@Param("muscleGroup") String muscleGroup,
                           @Param("equipment") String equipment,
                           @Param("search") String search);
}
